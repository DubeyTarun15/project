<?php include'header.php' ?>



    <section id="boxes" class="row grey">
        <div class="center">
          <h1>Alcholic Drink</h1>
          <strong class="subHeading">Alcohol is one of the most widely used recreational drugs in the world.</strong>
          <div class="columns">
            <article class="news oneThird">
              <div>
                <h3><a href="#">Premium</a></h3>
                <div class="content"> <a href="#" class="imgHolder fullWidth"><img src="./imgs/btl/Product24-450x450.jpg.webp" alt=""></a>
                  <p>Alcohol is one of the most widely used recreational drugs in the world, and about 33% of all humans currently drink alcohol.</p>
                  <p>Alcohol is one of the most widely used recreational drugs in the world..</p>
                </div>
                <p class=" btnSmall"style="text-align: center;" >20 £</p>
                <div class="readMore"><a href="#" class="btn btnSmall"><span>Buy Now</span></a></div>
              </div>
            </article>
            <article class="news oneThird">
              <div>
                <h3><a href="#">Best selling</a></h3>
                <div class="content"> <a href="#" class="imgHolder fullWidth"><img src="./imgs/btl/Product12-450x450.jpg.webp" alt=""></a>
                  <p>Alcohol is one of the most widely used recreational drugs in the world, and about 33% of all humans currently drink alcohol.</p>
                  <p>Alcohol is one of the most widely used recreational drugs in the world..</p>
                </div><p class=" btnSmall"style="text-align: center;" >20 £</p>
                <div class="readMore"><a href="#" class="btn btnSmall"><span>Buy Now</span></a></div>
              </div>
            </article>
            <article class="news oneThird">
              <div>
                <h3><a href="#"> Popular</a></h3>
                <div class="content"> <a href="#" class="imgHolder fullWidth"><img src="./imgs/btl/Product13-450x450.jpg.webp" alt=""></a>
                  <p>Alcohol is one of the most widely used recreational drugs in the world, and about 33% of all humans currently drink alcohol.</p>
                  <p>Alcohol is one of the most widely used recreational drugs in the world..</p>
                </div><p class=" btnSmall"style="text-align: center;" >20 £</p>
                <div class="readMore"><a href="#" class="btn btnSmall"><span>Buy Now</span></a></div>
              </div>
            </article>
          </div>
        </div>
      </section>

      <!-- Section 2 -->


      
      <?php include'footer.php' ?>