<?php include'header.php' ?>

  <div id="" >
    <section class="row" >
      <div class="center">
        <h1>Hi! Drinkers</h1>
        <strong class="subHeading"> Find your drink ! Everything is here.</strong>
        <div class="gallery">
          <ul class="slides">
            <li><img src="./imgs/BLOG1-720x484.jpg.webp"alt=""></li>
          </ul>
        </div>
        <div class="buttons"> <a href="./alcoholic.php" class="btn btnGreen"><span>Alcoholic</span></a> <span><em>or</em></span> <a href="./non_alcoholic.php" class="btn btnBlue"><span>Non-Alcoholic</span></a> </div>
      </div>
    </section>

    <section id="twoColumnLayout" class="row grey">
      <div class="center">
        <h1>Drink</h1>
        <strong class="subHeading">According to the preconceived notion, drinking alcohol is harmful to the body.</strong>
        <div class="columns">
          <div class="half">
            <div class="imgHolder alignLeft"><img src="./imgs/btl/Product14.jpg.webp" alt=""></div>
            <p>Alcoholic beverages are fermented from the sugars in fruits, berries, grains, and such other ingredients as plant saps, tubers, honey, and milk and may be distilled to reduce the original watery liquid to a liquid of much greater alcoholic strength.</p>

            <p> Beer is the best-known member of the malt family of alcoholic beverages, which also includes ale, stout, porter, and malt liquor. </p>
            <ul>
              <li>The main styles of sherries, listed from driest and palest </li>
              <li>Authentic sherry comes from the sherry region, </li>
            </ul>
           
          </div>
          <div class="half">
            <div class="imgHolder fullWidth"><img src="./imgs/btl/Product20-450x450.jpg.webp" alt=""></div>
            <p>Alcoholic beverages are fermented from the sugars in fruits, berries, grains, and such other ingredients as plant saps, tubers, honey, and milk and may be distilled to reduce the original watery liquid to a liquid of much greater alcoholic strength.</p>
            <p>Alcoholic beverages are fermented from the sugars in fruits, berries, grains, and such other ingredients as plant saps, tubers, honey, and milk and may be distilled to reduce the original watery liquid to a liquid of much greater alcoholic strength.</p>
          </div>
        </div>
      </div>
    </section>

    
    <section id="threeColumnLayout" class="row">
      <div class="center">
        <h1>Three Column Layout</h1>
        <strong class="subHeading">According to the preconceived notion, drinking alcohol is harmful to the body.</strong>
        <div class="columns">
          <div class="oneThird">
            <div class="imgHolder fullWidth"><img src="./imgs/john-hernandez-0-4zzoh3JXU-unsplash.jpg" alt=""></div>
            <p>The main styles of sherries, listed from driest and palest Authentic sherry comes from the sherry region,  vehicula pharetra, massa <a href="#">tellus elementum</a> nunc, eu pulvinar urna risus a orci.</p>
            <p>Ut scelerisque, sapien in luctus ultrices, magna ante convallis orci</p>
          </div>
          <div class="oneThird">
            <p>The main styles of sherries, listed from driest and palest Authentic sherry comes from the sherry region,  vehicula pThere are two styles of vermouth: the so-called French.</p>
            <ul>
              <li>The main styles of sherries, listed from driest and palest </li>
              <li>Authentic sherry comes from the sherry region, </li>
              <li>pThere are two styles of vermouth: the so-called French</li>
            </ul>
            <p>The process of blending wines involves what is known as the solera system </p>
            <p>In luctus, tortor vel vehicula pharetra, massa tellus. S ss fit amet, consectetur adipiscing elit. </p>
            <p>The process of blending wines involves what is known as the solera system </p>
          </div>
          <div class="oneThird">
            <div class="imgHolder alignLeft"><img src="./imgs/banner24.jpg.webp" alt=""></div>
            <p>The process of blending wines involves what is known as the solera system</p>
            <p>Alcoholic beverages are fermented from the sugars in fruits, berries, grains, and such other ingredients as plant saps, tubers, honey, and milk and may be distilled to reduce the original watery liquid to a liquid of much greater alcoholic strength.</p>
          </div>
        </div>
      </div>
    </section>

    <section id="boxes" class="row grey">
      <div class="center">
        <h1>Drink</h1>
        <strong class="subHeading">Alcohol is one of the most widely used recreational drugs in the world.</strong>
        <div class="columns">
          <article class="news oneThird">
            <div>
              <h3><a href="#">Premium</a></h3>
              <div class="content"> <a href="#" class="imgHolder fullWidth"><img src="./imgs/btl/Product24-450x450.jpg.webp" alt=""></a>
                <p>Alcohol is one of the most widely used recreational drugs in the world, and about 33% of all humans currently drink alcohol.</p>
                <p>Alcohol is one of the most widely used recreational drugs in the world..</p>
              </div>
              <div class="readMore"><a href="#" class="btn btnSmall"><span>Buy Now</span></a></div>
            </div>
          </article>
          <article class="news oneThird">
            <div>
              <h3><a href="#">Best selling</a></h3>
              <div class="content"> <a href="#" class="imgHolder fullWidth"><img src="./imgs/btl/Product12-450x450.jpg.webp" alt=""></a>
                <p>Alcohol is one of the most widely used recreational drugs in the world, and about 33% of all humans currently drink alcohol.</p>
                <p>Alcohol is one of the most widely used recreational drugs in the world..</p>
              </div>
              <div class="readMore"><a href="#" class="btn btnSmall"><span>Buy Now</span></a></div>
            </div>
          </article>
          <article class="news oneThird">
            <div>
              <h3><a href="#"> Popular</a></h3>
              <div class="content"> <a href="#" class="imgHolder fullWidth"><img src="./imgs/btl/Product13-450x450.jpg.webp" alt=""></a>
                <p>Alcohol is one of the most widely used recreational drugs in the world, and about 33% of all humans currently drink alcohol.</p>
                <p>Alcohol is one of the most widely used recreational drugs in the world..</p>
              </div>
              <div class="readMore"><a href="#" class="btn btnSmall"><span>Buy Now</span></a></div>
            </div>
          </article>
        </div>
      </div>
    </section>

    
    <section id="testiomonialsTab" class="row">
      <div class="center">
        <h1>Testimonials</h1>
        <strong class="subHeading">According to the preconceived notion, drinking alcohol is harmful to the body.</strong>
        <div id="testimonials" class="gallery">
          <ul class="slides">
            <li>
              <div class="row">
                <blockquote> <q> Alcohol is one of the most widely used recreational drugs in the world, and about 33% of all humans currently drink alcohol. </q> </blockquote>
                <blockquote> <q> Alcohol is one of the most widely used recreational drugs in the world, and about 33% of all humans currently drink alcohol. </q> </blockquote>
              </div>

            </li>
          </ul>
        </div>
      </div>
    </section>
  </div>



<?php include'footer.php' ?>