<?php include'header.php' ?>


            </body>

    <section id="contactUs" class="row grey">
        <div class="center">
          <h1>Contact Us</h1>
          <strong class="subHeading">Give your feedback</strong>
          <div class="columns">
            <div class="half">
              <form action="#" class="form">
                <fieldset>
                  <h2 style="text-align: center;">Feedback form</h2>
                  <div class="formRow">
                    <div class="textField">
                      <input type="text" placeholder="Your name ...">
                    </div>
                  </div><BR><br>
                  <div class="formRow">
                    <div class="textField">
                      <input type="text" placeholder="Your Email ...">
                    </div>
                  </div><BR><br>
                  <div class="formRow">
                    <div class="textField">
                      <textarea cols="20" rows="4" placeholder="Your Email ..."></textarea>
                    </div>
                  </div><BR><br>
                  <div class="formRow">
                    <button class="btnSmall btn submit right"> <span>Send Message</span> </button>
                    
                  </div>
                </fieldset>
              </form>
            </div>
            <div class="half">
              <h2 style="text-align: center;">How to find us</h2>
              <div id="map">
                <div class="imgHolder"><img src="./imgs/thumbnail.jpeg" alt=""></div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <?php include'footer.php' ?>