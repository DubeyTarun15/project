<?php include 'functions.php' ?>
<?php include 'header.php' ?>

<?php

if (isset($_POST['signup'])) {
  $data = $_POST;
  $user_exists = email_exists($data['email']);
  if ($user_exists) {
    $response = [
      'type' => 'error',
      'message' => 'Email is Already Taken!',
    ];
  } else {
    if ($data["password"] == $data["cpassword"]) {
      $data["type"] = 'user';
      $user = signup($data);
      if ($user) {
        $response = [
          'type' => 'success',
          'message' => 'User Registered Successfully!',
        ];
        login($data);
      } else {
        $response = [
          'type' => 'error',
          'message' => 'Some Error Occured!',
        ];
      }
    } else {
      $response = [
        'type' => 'error',
        'message' => 'Passwords should match!',
      ];
    }
  }
}

?>


    <section id="contactUs" class="row grey">
        <div class="center">
          <h1>Sign In</h1>
          <?php if (isset($response)) { ?>
                        <div class="message-box <?= $response['type'] ?>">
                            <p><?= $response['message'] ?></p>
                        </div>
                    <?php } ?>
          <strong class="subHeading">Give your Information</strong>
          <div class="columns">
            <div class="half">
              <form action="?" method="POST" class="form">
                <fieldset>
                  <h2 style="text-align:center ;">Log In</h2><br>
                  <div class="formRow">
                    <div class="textField">
                      <input type="text" name="fname" placeholder="Your First Name ...">
                    </div>
                  </div><br><br>
                  <div class="textField">
                      <input type="text" name="lname" placeholder="Your Last Name ...">
                    </div>
                    </div><br><br>
                  <div class="formRow">
                    <div class="textField">
                      <input type="text" name="email" placeholder="Your Email ...">
                    </div>
                  </div>
                  <br><br>
                  <div class="formRow">
                    <div class="textField">
                      <input type="password" name="password" placeholder="Password">
                    </div>
                  </div><br><br>
                  <div class="formRow">
                    <div class="textField">
                      <input type="password" name="cpassword" placeholder="Comfirm Password">
                    </div>
                  </div>
                  <div class="formRow" style="text-align:center ;">
                    <button type="submit" name="signup" class="btnSmall btn submit"> <span>Register</span> </button><br><br>
                  </div>
                </fieldset>
              </form>
            </div>
            <div class="half">
              <h2 style="text-align:center ;">Sign In our page</h2><br>
                <div class="imgHolder"><img src="./imgs/undraw_my_password_re_ydq7.svg" alt=""></div>
            </div>
          </div>
        </div>
      </section>
      <?php include'footer.php' ?>