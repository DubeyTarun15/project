<footer id="footer" style="background-image: url(./imgs/about2.jpg);">
    <div class="columns" style="padding: 0px 20px ;">
      <div class="half">
        <ul style="padding: 30px;">
          <h4 ><a href="./index.html">Home</a></h4>
          <br>
          <p <a href="#">About</a></p>
          <p <a href="#">Login</a></p>
        </ul>
      </div>
      <div class="half">
        <ul>
          <h4>Street Name & Number, Town, Postcode/Zip</h4>
          <br>
          <p>+0044-456 7890</p>
          <p>bar_cc.com</p>
        </ul>
          
      </div>
    </div>
  </footer>
</body>
</html>
