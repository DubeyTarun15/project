<?php include 'functions.php' ?>
<?php include 'header.php' ?>

<?php

if (isset($_POST['login'])) {
  $data = $_POST;
  $user = login($data);
  if (!$user) {
    $response = [
      'type' => 'error',
      'message' => 'Login Failed!'
    ];
  } else {
    header("Location: index.php");
  }
}

?>


    <section id="contactUs" class="row grey">
        <div class="center">
        
          <h1>Login</h1>
          <strong class="subHeading">Give your Id and Password</strong>
          <div class="columns">
            <div class="half">
            <?php if (isset($response)) { ?>
          <div class="message-box <?= $response['type'] ?>">
            <p><?= $response['message'] ?></p>
          </div>
        <?php } ?>
        <form action="?" method="POST">
          <div>
            <label for="email">Email Address</label>
            <input type="email" name="email" id="email" placeholder="Enter Email Address" required />
          </div>
          <div>
            <label for="password">Password</label>
            <input type="password" name="password" id="password" placeholder="Enter Password" required />
          </div>
          <button type="submit" name="login" class="btn">Login</button>
        </form>
            </div>
            <div class="half">
              <h2 style="text-align:center ;">Login our page</h2><br>
                <div class="imgHolder"><img src="./imgs/undraw_login_re_4vu2.svg" alt=""></div>
            </div>
          </div>
        </div>
      </section>

      <?php include'footer.php' ?>