<?php include'header.php' ?>



    <section id="twoColumnLayout" class="row grey">
        <div class="center">
          <h1>About</h1>
          <strong class="subHeading">According to the preconceived notion, drinking alcohol is harmful to the body.</strong>
          <div class="columns">
            <div class="half">
              <div class="imgHolder alignLeft"><img src="./imgs/BLOG1-720x484.jpg.webp" alt=""></div>
              <p> Beer is the best-known member of the malt family of alcoholic beverages, which also includes ale, stout, porter, and malt liquor. </p>
              <ul>
                <li>The main styles of sherries, listed from driest and palest </li>
                <li>Authentic sherry comes from the sherry region, </li>
              </ul>
              <p>Ut scelerisque, sapien in luctus ultrices, <a href="#">magna ante convallis</a> orci, vel iaculis massa sapien sed risus.</p>
              
            </div>
            <div class="half">
              <div class="imgHolder fullWidth"><img src="./imgs/BLOG3-720x484.jpg.webp" alt=""></div>
              <p>Alcoholic beverages are fermented from the sugars in fruits, berries, grains, and such other ingredients as plant saps, tubers, honey, and milk and may be distilled to reduce the original watery liquid to a liquid of much greater alcoholic strength.</p>
              <p>Alcoholic beverages are fermented from the sugars in fruits, berries, grains, and such other ingredients as plant saps, tubers, honey, and milk and may be distilled to reduce the original watery liquid to a liquid of much greater alcoholic strength.</p>
            </div>
          </div>
        </div>
      </section>


    <section id="testiomonialsTab" class="row">
        <div class="center">
          <strong class="subHeading">An alcoholic beverage is a drink that contains ethanol, a type of alcohol that acts as a drug and is produced by fermentation.</strong>
          <div id="testimonials" class="gallery">
            <ul class="slides">
              <li>
                <div class="row">
                  <blockquote> <q>Vodka, gin, baijiu, shōchū, soju, tequila, rum, whisky, brandy, and singani are examples of distilled drinks. Beer, wine, cider, sake, and huangjiu are examples of fermented drinks. </q> </blockquote>
                  <blockquote> <q>Vodka, gin, baijiu, shōchū, soju, tequila, rum, whisky, brandy, and singani are examples of distilled drinks. Beer, wine, cider, sake, and huangjiu are examples of fermented drinks. </q> </blockquote>
                </div>
                <div class="row">
                  <blockquote> <q>Vodka, gin, baijiu, shōchū, soju, tequila, rum, whisky, brandy, and singani are examples of distilled drinks. Beer, wine, cider, sake, and huangjiu are examples of fermented drinks. </q> </blockquote>
                  <blockquote> <q>Vodka, gin, baijiu, shōchū, soju, tequila, rum, whisky, brandy, and singani are examples of distilled drinks. Beer, wine, cider, sake, and huangjiu are examples of fermented drinks.. </q> </blockquote>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </section>
      <?php include'footer.php' ?>